<template>
    <div>
        <h2>INSCRIPTION</h2>
        <input v-model="email" type="email">
        <input v-model="password" type="password">
        <button @click="inscription(email, password)"> inscription </button>

    </div>
</template>

<script>
module.exports = {
    data(){
        return{
            email : "",
            password : "",
        }
    },
    methods : {
        inscription(email, mdp){
            this.$emit("inscription", email, mdp);
        }
    }
}
</script>