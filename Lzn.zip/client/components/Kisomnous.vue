<template>
  <div>
    <div class="landing">
    <div class="home-wrap">
      <div class="home-inner"> 
        <img src="cover5.png"> 
        </div>
    </div>
  </div>
  <div class="caption text-center">
    <h1> Welcome to E-CHIEF!</h1>
    <h3> Find your happiness! Discover a new dish  </h3>
  </div>
   <div id="course" class="offset">
    <div class="col-12 narrow text-center">
      <h1 class=heading> History of our website</h1>
      <div class="heading-underline"></div>
      <p class="lead"> This site allows you to discover new dishes. 
          The plate in head. Since the 1960's and Epinal's image of the meal taken at home, in family, with products bought from the small corner shopkeeper and a unique menu, the food consumption patterns of the French have changed a lot.
           While food has become a less and less expensive item in the household budget, it remains a major concern for the French, who are increasingly adapting their meals for environmental, health or medical reasons.
           <strong>Thanks to E-CHIEF you can organize yourself better and more easily when it comes to your meals. We offer you dishes from different countries but also in relation to the diet of some.</strong>
      </p>
    </div>
    </div>
    <div class="jumbotron">
        <div class="narrow text-center">
            <div class="col-12">
                <h1 class="heading"> Notre équipe </h3>
                 <div class="heading-underline"></div>
            </div>
    <div id="contenu">
        <section id="articles">
            <article>
                <h2>Navirash Tharmaseelan</h2>
                <h5> Engineering student</h5>
                <p> Passionate about cooking, I would like to bring my experience and help many people to eat well. But especially not to eat the same thing. </p>
                <a href="" target="_blank">Pour en savoir plus <i class="fab fa-linkedin"></i> </a>
            </article>
            <article>
                <h2>Lucas Maiz</h2>
                <h5> Engineering student</h5>
                <p> Passionate about cooking, I would like to bring my experience and help many people to eat well. But especially not to eat the same thing. </p>
                <a href="" target="_blank">Pour en savoir plus <i class="fab fa-linkedin"></i> </a>
            </article>
            <article>
                <h2>Amine Diouri</h2>
                <h5> Engineering student</h5>
                <p> Passionate about cooking, I would like to bring my experience and help many people to eat well. But especially not to eat the same thing.</p>
                <a href="" target="_blank">Pour en savoir plus <i class="fab fa-linkedin"></i> </a>
            </article>
            <article>
                <h2>Théo Vu</h2>
                <h5> Engineering student</h5>
                <p> Passionate about cooking, I would like to bring my experience and help many people to eat well. But especially not to eat the same thing. </p>
                <a href="" target="_blank">Pour en savoir plus <i class="fab fa-linkedin"></i> </a>
            </article>
            <article>
                <h2> Hugo Feruglio </h2>
                <h5>Engineering student</h5>
                <p> Passionate about cooking, I would like to bring my experience and help many people to eat well. But especially not to eat the same thing.</p>
                <a href="" target="_blank"> Pour en savoir plus <i class="fab fa-linkedin"></i> </a>
            </article>
        </section>
    </div>
    </div>
    </div>
    <div id="course" class="offset">
    <div class="col-12 narrow text-center">
      <h1 class=heading> Our goal</h1>
      <div class="heading-underline"></div>
      <p class="lead"> <strong>Our goal is to help many people with diabetes adapt their diet.</strong> Today, we no longer talk about a diet for diabetics but about a balanced diet, in which each of the food groups will have its own importance. In order to balance one's meals, it will be necessary to respect certain simple dietary principles, to acquire some knowledge about food and to know their nutritional interests.
      </p>
    </div>
    </div>
    <div class="jumbotron">
    <section id="contact">
        <div class="wrapper">
            <h1 class="heading">Contact us</h1>
            <div class="heading-underline"></div>
            <p class="lead">At E-CHIEF we would be delighted to hear your suggestions for improvement. Please feel free to leave us messages and we will get back to you. Thank you! </p>

            <form>
                <label for="name">Name</label>
                <input type="text" id="name" placeholder="Your Name">

                <label for="email">Email</label>
                <input type="text" id="email" placeholder="Your email">
                <input type="submit" value="Send" class="button-3">
            </form>
        </div>
        </section>
    </div>
    <div id="course" class="offset">
    <div class="col-12 narrow text-center">
      <h1 class=heading>The Future</h1>
      <div class="heading-underline"></div>
      <p class="lead"> Our future is to offer you other features such as tutorials to learn how to cook. We want to revolutionize the habits of many French people, in France, food is an important subject. Adepts of gastronomy and the joys of the table, the French have always been attentive to what's on their plate ... and are even more so now. Concerned about their health, the environment, or the social impact of the products they consume, the French are eating better and better, at all levels.
      </p>
    </div>
    </div>
    <footer>
        <div class="row justify-content-center">   
          <div class="col-md-5 text-center">
            <img src="echief.png">     <strong>E-CHIEF</strong>
            <p>Come and discover our famous recipes. At E-CHIEF we will be available 24/7 for all information. Please contact us by email or phone. We wish you a pleasant visit through our website. Thank you! </p>
            <strong> Contact information </strong>
            <p>+442041345678<br>e-chief@outlook.com</p>
            <a href="" target="_blank"><i class="fab fa-facebook-square"></i></a>
            <a href="" target="_blank"><i class="fab fa-twitter-square"></i></a>
            <a href="" target="_blank"><i class="fab fa-linkedin"></i></a>
          </div>
          <hr class="socket">
          Copyright © All rights reserved.
        </div>
      </footer>
  </div>
</template>

<script>
module.exports = {
  data () {
    return {
    }
  },
  async mounted () {
  },
  methods: {
    
  }
}
</script>

<style scoped>
.home-inner img{
  height:600px;
  width:100%;
}

.caption{
  width:100%;
  max-width:100%;
  position:absolute;
  top:38%;
  z-index:1;
  color:white;
  text-transform:uppercase;
}

.caption h1{
  font-size:4.5rem;
  font-weight:700;
  letter-spacing:.3rem;
  text-shadow: .1rem .1rem .8rem black;
  padding-bottom: 1rem;
}
.caption h3{
  font-size: 1.5rem;
  text-shadow: .1rem .1rem .5rem black;
  padding-bottom:1.6rem;
}

.narrow{
  width:75%; 
  margin: 1.5rem auto;
  padding-top:2rem;
}

.narrow h1{
  font-size:2.4rem;
}
h1.heading{
  font-size:1.9rem;
  font-weight:700;
  text-transform:uppercase;
  margin-bottom:1.9rem;
}
.heading-underline{
  width:3rem;
  height: .2rem;
  background-color:#FF69B4;
  margin:0 auto 2rem;
}

#articles
{
    display:flex;
    flex-wrap: wrap;
    text-align:center;
    width:auto;
    
}
article
{
    background : white;
    margin: 5px;
    margin-bottom: 20px;
    width:250px;
    padding:30px;
    line-height:30px;
    color:#8e8b8b;
    position: relative;
    border-style: inset;
 
}

article h2
{
    color:	#FF1493;
    font-size:26px;
}

article p
{
    color:black;
    font-size:15px;

}

article a {
   color:	#DB7093;
}
#contenu {
    max-width: 1900px;
    margin: auto;
}
.jumbotron{
  margin-bottom:0;
  padding:2rem 0 3.5rem;
  border-radius:0;
  background-color:rgb(255,192,203,0.25);

}
#contact
{
    padding: 60px 0;
    text-align: center
}


form
{
    margin: 60px 0 20px 0;
}
label
{
    font-weight: bold;
    font-size: 20px;
    margin-right: 10px;
    color: #777;
}

input[type="text"]
{
    padding:10px;
    font-size: 20px;
    margin-right: 20px;
    border: 2px solid #ddd;
    border-radius: 3px; 
}

.button-3
{
    color: #fff;
    font-size: 20px;
    font-weight: bold;
    padding: 11px;
    background-color:#F5D1CC ;
    border-style: none;
    border-radius: 3px;
}
.button-3:hover
{
    color: #fff;
    background-color: #444;
}
.wrapper
{
    width: 1100px;
    margin: 0 auto;
    padding: 0 10px;
}
footer{
  background-color:#F5D1CC;
  color:black;
  padding:2rem 0 2rem;
  margin-top:1rem;
}

footer img {
  height:4rem;
  margin:1.5rem 0;
}

footer a {
  color:#FF69B4;
}

footer svg.svg-inline--fa {
  font-size:2rem;
  margin:1.2rem .5rem 0 0;
}

footer svg.svg-inline--fa:hover {
  color:#FF1493;
}
hr.socket{
  width:100%;
  border-top:.2rem solid #FF1493;
  margin-top:3rem;
}
</style>