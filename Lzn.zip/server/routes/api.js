const express = require('express')
const router = express.Router()
const request = require('request')

const bcrypt = require('bcrypt')
const { Client } = require('pg')
const { text } = require('express')


const client = new Client({
 user: 'postgres',
 host: 'localhost',
 password: 'Ribambelle1',
 database: 'Projet_transverse'
})

client.connect()


router.get('/recipes/:kqk', (req, res) => {
  request('https://api.spoonacular.com/recipes/findByIngredients?apiKey=92f4c88770fd41fdbd818568704460b3&ingredients='+req.params.kqk+'&number=10', { json: true }, (err, body) => {
    if (err) { return console.log(err); }    
    res.json(body.body);
  });  
})

router.get('/informations/:id', (req,res) => {
  request('https://api.spoonacular.com/recipes/'+req.params.id+'/information?apiKey=92f4c88770fd41fdbd818568704460b3', { json: true }, (err, body) => {
    if (err) { return console.log(err); }
    res.json({url : body.body.sourceUrl, diets : body.body.diets});
  });
})

router.post('/register', async (req,res) => {
  Remail = req.body.email;
  Rmdp = req.body.mdp;
  if(Remail == "" || Rmdp== ""){
    res.json("Bad request - please enter your email adress and your password");
  }
  const hashmdp = await bcrypt.hash(Rmdp, 10);
  let alreadyexists = false;
  const op = await client.query({
    text : "SELECT * FROM users"
  })
  console.log(op.rows);
  let i = 0;
  while(i<op.rows.length && alreadyexists!=true){
    if(op.rows[i].email == Remail){
      alreadyexists = true;
    }
    i++;
  }
  if(alreadyexists == false) {
    const op2 = await client.query({
      text : "INSERT INTO users(email,password) VALUES ($1,$2)",
      values : [Remail, hashmdp]
    })
    res.json("Success");
  }
  else{
    res.json("This email adress already exists");
  }
})

router.post('/login', async (req,res) => {
  const Remail = req.body.email;
  const Rpassword = req.body.password;
  const op = await client.query({
    text : "SELECT * FROM users"
  })
  let i = 0
  while(i<op.rows.length){
    if(op.rows[i].email == Remail && await bcrypt.compare(Rpassword, op.rows[i].password)){
      req.session.userId = op.rows[i].id;
      res.json("Connected");
    }
    i++;
  }
  res.json("Email adress or password are incorrect");

})

/*
 * Cette route doit ajouter un article au panier, puis retourner le panier modifié à l'utilisateur
 * Le body doit contenir l'id de l'article, ainsi que la quantité voulue
 */
/*
router.post('/panier', (req, res) => {
   
   const tabArticles = articles;
   const Rquantity = Number(req.body.quantity);
   const Rid = Number(req.body.id);
   let i = 0;

   /*Vérifions que l'id demandé existe bien*//*
   while (tabArticles[i].id != req.body.id)
   {
    i = i + 1;
    if (i == tabArticles.length)
    {
      res.json({test : true, message : "ERROR- L'id selectionné ne fait référence à aucun article de la liste"});
      return;
    }
   }
*/
   /*Vérifions que "quantity" soit un nombre entier *//*
   if (! Number.isInteger(Rquantity)){
    res.json({test : true, message : "ERROR - La quantité indiquée n'est pas un entier"});
    return;
   }*/
  /* Vérifions que "quantity" soit strictement positif *//*
  if (Rquantity <= 0)
  {
    res.json({test : true, message : "ERROR - La quantité sélectionnée n'est pas strictement positive"});
    return;
  }*/

  /*Vérifions que l'article n'a pas déjà été ajouté au panier*//*
  const alreadyAdd= req.session.panier.articles;
  i = 0;
  while(i != alreadyAdd.length)
  {
    if(alreadyAdd[i].id == Rid){
      res.json({test : true, message : "ERROR - Cet article a déjà été ajouté"});
      return;
    }
    i = i + 1;
  }
  //Ajout de l'article au panier
  addArticle = {id : Rid, quantity : Rquantity};
  req.session.panier.articles.push(addArticle);

  res.json({test : false, article : req.session.panier});
})*/

/*
 * Cette route doit permettre de confirmer un panier, en recevant le nom et prénom de l'utilisateur
 * Le panier est ensuite supprimé grâce à req.session.destroy()
 *//*
router.post('/panier/pay', (req, res) => {
  let id = Number(req.session.userId);
  console.log(id);
  if(isNaN(id)){
    console.log("OK");
    id = 0;
  }
  console.log(id);
  if (id != 0){
    console.log(req.session.panier);
    req.session.destroy();

    res.json(true);
  }
  else{
    res.json(false);
  }
})*/

/*
 * Cette route doit permettre de changer la quantité d'un article dans le panier
 * Le body doit contenir la quantité voulue
 *//*
router.put('/panier/:articleId', (req, res) => {
  
  const Rid = Number(req.params.articleId);
  const Rquantity = Number(req.body.quantity);
  
  const tabArticlesPanier = req.session.panier.articles;
  
  let position = 0;
  let i = 0;
  //Nous vérifions que l'article à modifier soit bien dans le panier
  while (i != tabArticlesPanier.length){
    
    if(tabArticlesPanier[i].id == Rid){
      
      position = i;
      i = tabArticlesPanier.length;
    }
    else{
      i = i + 1;
      if (i == tabArticlesPanier.length)
      {
        res.json({test : true, message : "ERROR - L'article que vous voulez modifier n'est pas dans le panier"})
      }
    }
    
  }

  //Nous vérifions que la "nouvelle" quantité soit strictement supérieur à 0
  if(Rquantity <= 0)
  {
    res.json({test : true, message : "ERROR - La nouvelle quantité n'est pas strictement supérieur à 0"});
  }

  //Nous vérifions que la "nouvelle" quantité soit un entier
  if(!Number.isInteger(Rquantity)){
    res.json({test : true, message : "ERROR - La nouvelle quantité n'est pas un entier"});
  }

  tabArticlesPanier[position].quantity = Rquantity;

  console.log(req.session.panier.articles);
  res.json({test : false, article : req.session.panier});
})*/

/*
 * Cette route doit supprimer un article dans le panier
 *//*
router.delete('/panier/:articleId', (req, res) => {
  console.log("test 1");
  const Rid = Number(req.params.articleId);
  console.log(Rid);
  const tabArticlesPanier = req.session.panier.articles;
  let i = 0;
  let position = 0;
  //Nous vérifions que l'article à supprimer soit bien dans le panier
  while(i!=tabArticlesPanier.length){
    if (Rid == tabArticlesPanier[i].id) {
      position = i;
      i = tabArticlesPanier.length
    }
    else{
      i = i + 1;
      if (i == tabArticlesPanier.length)
      {
        res.json({message : "ERROR - L'article que vous voulez modifier n'est pas dans le panier"})
      }
    }
  }

  tabArticlesPanier.splice(position, 1);
  
  res.json(req.session.panier);

})
*/

/**
 * Cette route envoie l'intégralité des articles du site
 *//*
router.get('/articles', (req, res) => {
  res.json(articles)
})
*/
/**
 * Cette route crée un article.
 * WARNING: dans un vrai site, elle devrait être authentifiée et valider que l'utilisateur est bien autorisé
 * NOTE: lorsqu'on redémarre le serveur, l'article ajouté disparait
 *   Si on voulait persister l'information, on utiliserait une BDD (mysql, etc.)
 *//*
router.post('/article', (req, res) => {
  const name = req.body.name
  const description = req.body.description
  const image = req.body.image
  const price = parseInt(req.body.price)

  // vérification de la validité des données d'entrée
  if (typeof name !== 'string' || name === '' ||
      typeof description !== 'string' || description === '' ||
      typeof image !== 'string' || image === '' ||
      isNaN(price) || price <= 0) {
    res.status(400).json({ message: 'bad request' })
    return
  }

  const article = {
    id: articles.length + 1,
    name: name,
    description: description,
    image: image,
    price: price
  }
  articles.push(article)
  // on envoie l'article ajouté à l'utilisateur
  res.json(article)
}),*/

/*Route qui inscrit un utilisateur*//*
router.post('/register', async (req, res) => {

  const Rpassword = req.body.password;
  const Remail = req.body.email;
  let booleeen = true;
  
  const result = await client.query({ 
  text: 'SELECT email FROM users',
  })

  console.log(result.rows);
  for(let i=0; i<result.rows.length; i++)
  {
    if(Remail == result.rows[i].email){
      booleeen = false;
    }
  }

  if(booleeen == true){
  
    const hash = await bcrypt.hash(Rpassword, 10);
  
    const result2 = await client.query({
      text : 'INSERT INTO users(email, password) VALUES ($1, $2)',
      values : [Remail, hash]
    });
    
    res.json({message : 'Vous êtes à présent inscrit'});
  }
  else{
    res.json({ message: 'ERROR - Cette email existe déjà' });
  }


}),


router.post('/login', async (req, res) => {
  const Rpassword = req.body.password;
  const Rmail = req.body.email;
  let index = 0;
  let booleeen = false;
  const result = await client.query({ 
    text: 'SELECT * FROM users',
  })
  
  console.log(result.rows);
  for(let i=0; i<result.rows.length; i++)
  {
    if(Rmail == result.rows[i].email){
      if(await bcrypt.compare(Rpassword, result.rows[i].password))
      {
        index = i;
        booleeen = true;
      }
    }
  }


  if(booleeen == true){
    
    req.session.userId = result.rows[index].id;
    console.log("Nouvel userId", result.rows[index].id)
    res.json({num_id : result.rows[index].id, message : "GENIAL CA MARCHE"})
    
  
    
  }
  else{
    res.json({message : "ERROR "})
  }
}),

router.get('/me', async (req, res) => {
  const num_id = Number(req.session.userId);
  console.log("NUM_ID", num_id);
  let index = 0;
  if(num_id == 0){
    res.json({error : "ERROR - 401"})
  }

  const result = await client.query({ 
    text: 'SELECT id, email FROM users',
    })

    console.log(result.rows);

    for(let i=0; i<result.rows.length; i++){
      if(num_id == result.rows[i].id){
        index = i;
      }
    }

  console.log(result.rows[index].email)
  res.json(result.rows[index].email)
})
*/

/**
 * Cette fonction fait en sorte de valider que l'article demandé par l'utilisateur
 * est valide. Elle est appliquée aux routes:
 * - GET /article/:articleId
 * - PUT /article/:articleId
 * - DELETE /article/:articleId
 * Comme ces trois routes ont un comportement similaire, on regroupe leurs fonctionnalités communes dans un middleware
 *//*
function parseArticle (req, res, next) {
  const articleId = parseInt(req.params.articleId)

  // si articleId n'est pas un nombre (NaN = Not A Number), alors on s'arrête
  if (isNaN(articleId)) {
    res.status(400).json({ message: 'articleId should be a number' })
    return
  }
  // on affecte req.articleId pour l'exploiter dans toutes les routes qui en ont besoin
  req.articleId = articleId

  const article = articles.find(a => a.id === req.articleId)
  if (!article) {
    res.status(404).json({ message: 'article ' + articleId + ' does not exist' })
    return
  }
  // on affecte req.article pour l'exploiter dans toutes les routes qui en ont besoin
  req.article = article
  next()
}

router.route('/article/:articleId')*/
  /**
   * Cette route envoie un article particulier
   *//*
  .get(parseArticle, (req, res) => {
    // req.article existe grâce au middleware parseArticle
    res.json(req.article)
  })*/

  /**
   * Cette route modifie un article.
   * WARNING: dans un vrai site, elle devrait être authentifiée et valider que l'utilisateur est bien autorisé
   * NOTE: lorsqu'on redémarre le serveur, la modification de l'article disparait
   *   Si on voulait persister l'information, on utiliserait une BDD (mysql, etc.)
   *//*
  .put(parseArticle, (req, res) => {
    const name = req.body.name
    const description = req.body.description
    const image = req.body.image
    const price = parseInt(req.body.price)

    req.article.name = name
    req.article.description = description
    req.article.image = image
    req.article.price = price
    res.send()
  })

  .delete(parseArticle, (req, res) => {
    const index = articles.findIndex(a => a.id === req.articleId)

    articles.splice(index, 1) // remove the article from the array
    res.send()
  })
*/
module.exports = router
